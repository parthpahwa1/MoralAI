# Commonsense Norm Bank
Commonsense Norm Bank is a moral textbook machines that compiles 1.7 million examples of people’s ethical judgments on a broad spectrum of everyday situations. Commonsense Norm Bank consists of three tasks: moral acceptability, moral agreement, and moral comparison.

### Free-form Mode
Free-form mode is the task of given a real-life situation, providing a moral judgment to the situation. This data set contains the following columns: 

- `input_sequence`: A moral situation
- `class_label`: The moral judgment of the situation: good (1), bad (-1), discretionary (0)
- `text_label`: An open text moral judgment
- `input_type`: Whether `input_sequence` is a positive rule-of-thumb (positive_rot) or a negative rule-of-thumb (negative_rot)*
- `format`: The format template used to generate `input_sequence`
- `source`: The data set the situation originates from

### Yes/no Mode
Yes/no mode is the task of given a moral judgment (e.g., "women cannot be scientists", "it's kind to express concern over your neighbor's friends"), determining whether society at large would agree or disagree with the statement. This data set contains the following columns: 

- `input_sequence`: A moral judgment
- `class_label`: The moral judgment of the situation: good (1), bad (-1), discretionary (0)
- `text_label`: An open text moral judgment
- `input_type`: Whether `input_sequence` is a positive rule-of-thumb (positive_rot) or a negative rule-of-thumb (negative_rot)*
- `source`: The data set the judgment originates from

* For more information on rule-of-thumbs, please refer to the [Social Chemistry paper](https://arxiv.org/abs/2011.00620).

### Relative Mode
Relative mode is the task of given two situations, determining which situation is morally better over another. **We exclude this portion of the dataset from the Commonsense Norm Bank release because it was not trained with data that alleviate stereotypes or biased point of views towards social and demographic groups that are conventionally underrepresented when applying ethical judgments. Thus, this task is prone to problematic and harmful output.** However, if you would like to have access to this dataset, please contact [delphi@allenai.org](mailto:delphi@allenai.org). For more information on the relative mode task, please refer to the [Aligning AI with Shared Human Values](https://arxiv.org/pdf/2008.02275.pdf) paper by Hendryks et al.

This data set contains the following columns: 

- `action_1`: A moral situation
- `action_2`: A moral situation different than `action_1`
- `targets`: Which of the moral situations (1 or 2) is morally better

## Disclaimer
Commonsense Norm Bank may contain language that is offensive, problematic, or harmful. By accessing the data set, you acknowledge you may encounter such language in the data set.

## License
Commonsense Norm Bank is licensed under the [Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License] (https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode). By accessing the data set, you agree to follow the terms outlined in the license.